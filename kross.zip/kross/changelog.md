## Version 1.0.0 (4 aug 2019)
- Initial template
- Bootstrap version 4.1.1

## Version 1.0.1 (26 oct 2021)
- Remove bwnista font
